<?php
$con = mysqli_connect("localhost","root","") or die("could not connect");
mysqli_select_db($con,"search_test") or die("could not find db");
$output = '';
//connect
if(isset($_POST['search'])){
	$searchq = $_POST['search'];
	$searchq = preg_replace("#[^0-9a-z]#i","",$searchq);
	
	
	$sql = "SELECT *FROM members WHERE firstname LIKE '%$searchq%' OR lastname LIKE '%$searchq%' OR phoneno LIKE '%$searchq%' " or die("coukd not search");
	$query = mysqli_query($con,$sql);
	
	$count = mysqli_num_rows($query);
	if($count == 0){
		$output = 'There was no search results!';
	
	}else{
		
		while($row = mysqli_fetch_array($query)){
			$fname = $row['firstname'];
			$lname = $row['lastname'];
			$tim = $row['phoneno'];
			$id = $row['id'];
			$output .= '<div>'.$fname.' '.$lname.'</div>';
			
			
		}
	}
}





?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://wwww.w3.org/TR/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-eqiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Search</title>
	
	<link rel="stylesheet" type="text/css" href="style.css">



</head>
<body>

	


	<form action="index.php" method="post">
		<input type="text" name="search" placeholder="Search for members.."  />
	
		<input type="submit" value="go" />


	</form>

</body>
</html>
<?php

print($output);
?>








