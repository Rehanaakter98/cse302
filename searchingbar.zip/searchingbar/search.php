<?php
$con = mysqli_connect("localhost","root","") or die("could not connect");
mysqli_select_db($con,"search_test") or die("could not find db");
$output = '';
//connect
if(isset($_POST['searchVal'])){
	$searchq = $_POST['searchVal'];
	$searchq = preg_replace("#[^0-9a-z]#i","",$searchq);
	
	
	$sql = "SELECT *FROM members WHERE firstname LIKE '%$searchq%' OR lastname LIKE '%$searchq%' OR phoneno LIKE '%$searchq%' " or die("coukd not search");
	$query = mysqli_query($con,$sql);
	
	$count = mysqli_num_rows($query);
	if($count == 0){
		$output = 'There was no search results!';
	
	}else{
		
		while($row = mysqli_fetch_array($query)){
			$fname = $row['firstname'];
			$lname = $row['lastname'];
			$id = $row['id'];
			$output = '<div>'.$fname.' '.$lname.'</div>';
			
			
		}
	}
}
echo($output);



?>
